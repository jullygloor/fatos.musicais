const poprep = document.getElementById("popRap");

poprep.addEventListener("click", () => {
    window.location.href = "./popRap.html";
});

const td = document.getElementById("tudo");

td.addEventListener("click", () => {
    window.location.href = "./index.html";
});

const jb = document.getElementById("Jazz&Blues");

jb.addEventListener("click", () => {
    window.location.href = "./blues.html";
});

const mt = document.getElementById("metal");

mt.addEventListener("click", () => {
    window.location.href = "./metal.html";
});

const br = document.getElementById("R&B");

br.addEventListener("click", () => {
    window.location.href = "./rb.html";
});

const hop = document.getElementById("Hip-Hop");

hop.addEventListener("click", () => {
    window.location.href = "./hip.html";
});

const ck = document.getElementById("Rock");

ck.addEventListener("click", () => {
    window.location.href = "./roc.html";
});

const ee = document.getElementById("Eletrônica");

ee.addEventListener("click", () => {
    window.location.href = "./eletronic.html";
});

const cp = document.getElementById("Compras");

cp.addEventListener("click", () => {
    window.location.href = "./compra.html";
});

